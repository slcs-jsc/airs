
int getpeereid(int s, uid_t *euid, gid_t *egid);
