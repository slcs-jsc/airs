/*   Updated for V6 by Feng Ding in January 2013 */

/* Structure holds an entire granule of airs_cc_rad */
typedef struct {

  /* Attributes */
  char            processing_level[256];
  char            instrument[256];
  char            DayNightFlag[256];
  char            AutomaticQAFlag[256];
  int             NumTotalData;
  int             NumProcessData;
  int             NumSpecialData;
  int             NumBadData;
  int             NumMissingData;
  int             NumLandSurface;
  int             NumOceanSurface;
  char            node_type[256];
  int             start_year;
  int             start_month;
  int             start_day;
  int             start_hour;
  int             start_minute;
  float           start_sec;
  int             start_orbit;
  int             end_orbit;
  int             orbit_path;
  int             start_orbit_row;
  int             end_orbit_row;
  int             granule_number;
  int             num_scansets;
  int             num_scanlines;
  double          start_Latitude;
  double          start_Longitude;
  double          start_Time;
  double          end_Latitude;
  double          end_Longitude;
  double          end_Time;
  float           eq_x_longitude;
  double          eq_x_tai;
  short           LonGranuleCen;
  short           LatGranuleCen;
  short           LocTimeGranuleCen;
  short           num_fpe;
  unsigned int    orbitgeoqa;
  short           num_satgeoqa;
  short           num_glintgeoqa;
  short           num_moongeoqa;
  short           num_ftptgeoqa;
  short           num_zengeoqa;
  short           num_demgeoqa;
  unsigned char   CalGranSummary;
  short           DCR_scan;
  char            granules_present_L1B[256];

  /* Geolocation fields */
  double           Latitude[AIRS_CC_RAD_GEOTRACK][AIRS_CC_RAD_GEOXTRACK];
  double           Longitude[AIRS_CC_RAD_GEOTRACK][AIRS_CC_RAD_GEOXTRACK];
  double           Time[AIRS_CC_RAD_GEOTRACK][AIRS_CC_RAD_GEOXTRACK];


  /* Data fields */
  float           radiances[45][30][2378];
  unsigned short  radiances_QC[45][30][2378];
  float           radiance_err[45][30][2378];
  float           CldClearParam[45][30][3][3];
  float           nominal_freq[2378];
  float           scanang[45][30];
  float           satheight[45];
  float           satroll[45];
  float           satpitch[45];
  float           satyaw[45];
  float           satzen[45][30];
  float           satazi[45][30];
  float           solzen[45][30];
  float           solazi[45][30];
  float           glintlat[45];
  float           glintlon[45];
  short           sun_glint_distance[45][30];
  double          nadirTAI[45];
  double          sat_lat[45];
  double          sat_lon[45];
  signed char     scan_node_type[45];
  float           topog[45][30];
  float           topog_err[45][30];
  float           landFrac[45][30];
  float           landFrac_err[45][30];
  unsigned int    ftptgeoqa[45][30];
  unsigned short  zengeoqa[45][30];
  unsigned short  demgeoqa[45][30];
  unsigned int    satgeoqa[45];
  unsigned short  glintgeoqa[45];
  unsigned short  moongeoqa[45];
  unsigned char   CalFlag[45][2378];
  unsigned char   CalScanSummary[45];
  unsigned char   CalChanSummary[2378];
  unsigned char   ExcludedChans[2378];
  float           orbit_phase_deg[45];
  float           shift_y0[45][17];
  float           scan_freq[45][2378];
  float           Doppler_shift_ppm[45][30];
  float           NeN_L1B[2378];
  float           NeN_L1B_Static[2378];
  short           dust_flag[45][30];
  float           CC_noise_eff_amp_factor[45][30];
  float           CC1_noise_eff_amp_factor[45][30];
  float           CC1_Resid[45][30];
  float           CCfinal_Resid[45][30];
  float           TotCld_4_CCfinal[45][30];
  float           CCfinal_Noise_Amp[45][30];
  signed char     invalid[45][30];
  signed char     all_spots_avg[45][30];
  signed char     MW_ret_used[45][30];
  signed char     bad_clouds[45][30];
  signed char     retrieval_type[45][30];


} airs_cc_rad_gran_t;

/* proptotype for reader function */
extern void airs_cc_rad_rdr(char * file_name, airs_cc_rad_gran_t * airs_cc_rad_gran );

