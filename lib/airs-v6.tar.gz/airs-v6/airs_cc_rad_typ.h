/* Constants for each dimension */
#define AIRS_CC_RAD_GEOXTRACK                        30
#define AIRS_CC_RAD_GEOTRACK                         45
#define AIRS_CC_RAD_CHANNEL                        2378
#define AIRS_CC_RAD_AIRSXTRACK                        3
#define AIRS_CC_RAD_AIRSTRACK                         3
#define AIRS_CC_RAD_MODULE                           17

