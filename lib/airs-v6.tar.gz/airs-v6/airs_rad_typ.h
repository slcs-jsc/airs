/* Constants for each dimension */
#define AIRS_RAD_GEOXTRACK                           90
#define AIRS_RAD_GEOTRACK                           135
#define AIRS_RAD_CALXTRACK                            6
#define AIRS_RAD_SPACEXTRACK                          4
#define AIRS_RAD_BBXTRACK                             1
#define AIRS_RAD_CHANNEL                           2378
#define AIRS_RAD_MAXREFCHANNEL                      100
#define AIRS_RAD_MAXFEATURESUPWELL                   35
#define AIRS_RAD_MAXFEATURESPARY                     17

/* Type definitions for each structure type */

typedef struct {
  float           min;
  float           max;
  float           mean;
  float           dev;
  int             num_in;
  int             num_lo;
  int             num_hi;
  int             num_bad;
  float           range_min;
  float           range_max;
  signed char     missing;
  int             max_track;
  int             max_xtrack;
  int             min_track;
  int             min_xtrack;
} airs_rad_input_bb_temp_t;

typedef struct {
  float           min;
  float           max;
  float           mean;
  float           dev;
  int             num_in;
  int             num_lo;
  int             num_hi;
  int             num_bad;
  float           range_min;
  float           range_max;
  signed char     missing;
  int             max_track;
  int             max_xtrack;
  int             min_track;
  int             min_xtrack;
} airs_rad_input_bb_temp1_t;

typedef struct {
  float           min;
  float           max;
  float           mean;
  float           dev;
  int             num_in;
  int             num_lo;
  int             num_hi;
  int             num_bad;
  float           range_min;
  float           range_max;
  signed char     missing;
  int             max_track;
  int             max_xtrack;
  int             min_track;
  int             min_xtrack;
} airs_rad_input_bb_temp2_t;

typedef struct {
  float           min;
  float           max;
  float           mean;
  float           dev;
  int             num_in;
  int             num_lo;
  int             num_hi;
  int             num_bad;
  float           range_min;
  float           range_max;
  signed char     missing;
  int             max_track;
  int             max_xtrack;
  int             min_track;
  int             min_xtrack;
} airs_rad_input_bb_temp3_t;

typedef struct {
  float           min;
  float           max;
  float           mean;
  float           dev;
  int             num_in;
  int             num_lo;
  int             num_hi;
  int             num_bad;
  float           range_min;
  float           range_max;
  signed char     missing;
  int             max_track;
  int             max_xtrack;
  int             min_track;
  int             min_xtrack;
} airs_rad_input_bb_temp4_t;

typedef struct {
  float           min;
  float           max;
  float           mean;
  float           dev;
  int             num_in;
  int             num_lo;
  int             num_hi;
  int             num_bad;
  float           range_min;
  float           range_max;
  signed char     missing;
  int             max_track;
  int             max_xtrack;
  int             min_track;
  int             min_xtrack;
} airs_rad_input_spec_temp_t;

typedef struct {
  float           min;
  float           max;
  float           mean;
  float           dev;
  int             num_in;
  int             num_lo;
  int             num_hi;
  int             num_bad;
  float           range_min;
  float           range_max;
  signed char     missing;
  int             max_track;
  int             max_xtrack;
  int             min_track;
  int             min_xtrack;
} airs_rad_input_ir_det_temp_t;

typedef struct {
  float           min;
  float           max;
  float           mean;
  float           dev;
  int             num_in;
  int             num_lo;
  int             num_hi;
  int             num_bad;
  float           range_min;
  float           range_max;
  signed char     missing;
  int             max_track;
  int             max_xtrack;
  int             min_track;
  int             min_xtrack;
} airs_rad_input_grating_temp_1_t;

typedef struct {
  float           min;
  float           max;
  float           mean;
  float           dev;
  int             num_in;
  int             num_lo;
  int             num_hi;
  int             num_bad;
  float           range_min;
  float           range_max;
  signed char     missing;
  int             max_track;
  int             max_xtrack;
  int             min_track;
  int             min_xtrack;
} airs_rad_input_grating_temp_2_t;

typedef struct {
  float           min;
  float           max;
  float           mean;
  float           dev;
  int             num_in;
  int             num_lo;
  int             num_hi;
  int             num_bad;
  float           range_min;
  float           range_max;
  signed char     missing;
  int             max_track;
  int             max_xtrack;
  int             min_track;
  int             min_xtrack;
} airs_rad_input_entr_filt_temp_t;

typedef struct {
  float           min;
  float           max;
  float           mean;
  float           dev;
  int             num_in;
  int             num_lo;
  int             num_hi;
  int             num_bad;
  float           range_min;
  float           range_max;
  signed char     missing;
  int             max_track;
  int             max_xtrack;
  int             min_track;
  int             min_xtrack;
} airs_rad_input_opt_bench_temp_2_t;

typedef struct {
  float           min;
  float           max;
  float           mean;
  float           dev;
  int             num_in;
  int             num_lo;
  int             num_hi;
  int             num_bad;
  float           range_min;
  float           range_max;
  signed char     missing;
  int             max_track;
  int             max_xtrack;
  int             min_track;
  int             min_xtrack;
} airs_rad_input_opt_bench_temp_3_t;

typedef struct {
  float           min;
  float           max;
  float           mean;
  float           dev;
  int             num_in;
  int             num_lo;
  int             num_hi;
  int             num_bad;
  float           range_min;
  float           range_max;
  signed char     missing;
  int             max_track;
  int             max_xtrack;
  int             min_track;
  int             min_xtrack;
} airs_rad_input_scan_mirror_temp_t;

typedef struct {
  float           min;
  float           max;
  float           mean;
  float           dev;
  int             num_in;
  int             num_lo;
  int             num_hi;
  int             num_bad;
  float           range_min;
  float           range_max;
  signed char     missing;
  int             max_track;
  int             max_xtrack;
  int             min_track;
  int             min_xtrack;
} airs_rad_input_chopper_phase_err_t;

typedef struct {
  float           min[2378];
  float           max[2378];
  float           mean[2378];
  float           dev[2378];
  int             num_in[2378];
  int             num_lo[2378];
  int             num_hi[2378];
  int             num_bad[2378];
  float           range_min[2378];
  float           range_max[2378];
  signed char     missing[2378];
  int             max_track[2378];
  int             max_xtrack[2378];
  int             min_track[2378];
  int             min_xtrack[2378];
} airs_rad_input_scene_counts_t;

typedef struct {
  float           min[4][2378];
  float           max[4][2378];
  float           mean[4][2378];
  float           dev[4][2378];
  int             num_in[4][2378];
  int             num_lo[4][2378];
  int             num_hi[4][2378];
  int             num_bad[4][2378];
  float           range_min[4][2378];
  float           range_max[4][2378];
  signed char     missing[4][2378];
  int             max_track[4][2378];
  int             max_xtrack[4][2378];
  int             min_track[4][2378];
  int             min_xtrack[4][2378];
} airs_rad_input_space_counts_t;

typedef struct {
  float           min[4][2378];
  float           max[4][2378];
  float           mean[4][2378];
  float           dev[4][2378];
  int             num_in[4][2378];
  int             num_lo[4][2378];
  int             num_hi[4][2378];
  int             num_bad[4][2378];
  float           range_min[4][2378];
  float           range_max[4][2378];
  signed char     missing[4][2378];
  int             max_track[4][2378];
  int             max_xtrack[4][2378];
  int             min_track[4][2378];
  int             min_xtrack[4][2378];
} airs_rad_input_space_signals_t;

typedef struct {
  float           min[4][2378];
  float           max[4][2378];
  float           mean[4][2378];
  float           dev[4][2378];
  int             num[4][2378];
  int             num_bad[4][2378];
  int             max_track[4][2378];
  int             max_xtrack[4][2378];
  int             min_track[4][2378];
  int             min_xtrack[4][2378];
} airs_rad_input_space_diffs_t;

typedef struct {
  float           min[2378];
  float           max[2378];
  float           mean[2378];
  float           dev[2378];
  int             num_in[2378];
  int             num_lo[2378];
  int             num_hi[2378];
  int             num_bad[2378];
  float           range_min[2378];
  float           range_max[2378];
  signed char     missing[2378];
  int             max_track[2378];
  int             max_xtrack[2378];
  int             min_track[2378];
  int             min_xtrack[2378];
} airs_rad_input_bb_counts_t;

typedef struct {
  float           min[2378];
  float           max[2378];
  float           mean[2378];
  float           dev[2378];
  int             num_in[2378];
  int             num_lo[2378];
  int             num_hi[2378];
  int             num_bad[2378];
  float           range_min[2378];
  float           range_max[2378];
  signed char     missing[2378];
  int             max_track[2378];
  int             max_xtrack[2378];
  int             min_track[2378];
  int             min_xtrack[2378];
} airs_rad_input_bb_signals_t;

typedef struct {
  float           min[2378];
  float           max[2378];
  float           mean[2378];
  float           dev[2378];
  int             num_in[2378];
  int             num_lo[2378];
  int             num_hi[2378];
  int             num_bad[2378];
  float           range_min[2378];
  float           range_max[2378];
  signed char     missing[2378];
  int             max_track[2378];
  int             max_xtrack[2378];
  int             min_track[2378];
  int             min_xtrack[2378];
} airs_rad_input_spec_counts_t;

typedef struct {
  float           min[2378];
  float           max[2378];
  float           mean[2378];
  float           dev[2378];
  int             num[2378];
  int             num_bad[2378];
  int             max_track[2378];
  int             max_xtrack[2378];
  int             min_track[2378];
  int             min_xtrack[2378];
} airs_rad_offset_stats_t;

typedef struct {
  float           min[2378];
  float           max[2378];
  float           mean[2378];
  float           dev[2378];
  int             num[2378];
  int             num_bad[2378];
  int             max_track[2378];
  int             max_xtrack[2378];
  int             min_track[2378];
  int             min_xtrack[2378];
} airs_rad_gain_stats_t;

typedef struct {
  float           min[2378];
  float           max[2378];
  float           mean[2378];
  float           dev[2378];
  int             num[2378];
  int             num_bad[2378];
  int             max_track[2378];
  int             max_xtrack[2378];
  int             min_track[2378];
  int             min_xtrack[2378];
} airs_rad_rad_stats_t;

typedef struct {
  float           min[90][100];
  float           max[90][100];
  float           mean[90][100];
  float           dev[90][100];
  int             num[90][100];
  int             num_bad[90][100];
  int             max_track[90][100];
  int             max_xtrack[90][100];
  int             min_track[90][100];
  int             min_xtrack[90][100];
} airs_rad_rad_scan_stats_t;

typedef struct {
  float           min[35];
  float           max[35];
  float           mean[35];
  float           dev[35];
  int             num_in[35];
  int             num_lo[35];
  int             num_hi[35];
  int             num_bad[35];
  float           range_min[35];
  float           range_max[35];
  signed char     missing[35];
  int             max_track[35];
  int             max_xtrack[35];
  int             min_track[35];
  int             min_xtrack[35];
} airs_rad_spec_feature_contrast_stats_t;

