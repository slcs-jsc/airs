/* Updated for V6 by Feng Ding in January 2013 */

/* Constants for each dimension */
#define AIRS_RET_GEOXTRACK                           30
#define AIRS_RET_GEOTRACK                            45
#define AIRS_RET_STDPRESSURELEV                      28
#define AIRS_RET_STDPRESSURELAY                      28
#define AIRS_RET_AIRSXTRACK                           3
#define AIRS_RET_AIRSTRACK                            3
#define AIRS_RET_CLOUD                                2
#define AIRS_RET_MWHINGESURF                          7
#define AIRS_RET_H2OFUNC                             11
#define AIRS_RET_O3FUNC                               9
#define AIRS_RET_COFUNC                               9
#define AIRS_RET_CH4FUNC                              7
#define AIRS_RET_HINGESURF                          100
#define AIRS_RET_H2OPRESSURELEV                      15
#define AIRS_RET_H2OPRESSURELAY                      14

